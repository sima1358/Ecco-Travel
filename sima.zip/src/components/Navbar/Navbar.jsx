import React from "react";
import "./navbar.css";
import { HiBriefcase } from "react-icons/hi";

export default function Navbar() {

   return (
    <section className="navbarSection">
      <header className="header flex">
        <div className="logoDiv">
          <a href="#" className="logo flex">
            <h1>
              <HiBriefcase className="icon"/>
              Eco Travel
            </h1>
          </a>
        </div>

        <div className="navbarDiv">
          <ul className="navbarUl">
            <li className="navItem">
                <a href="#" className="navLink">Home</a>
                <a href="#" className="navLink">Contact Us</a>
                <a href="#" className="navLink">Your Experiences</a>
                <a href="#" className="navLink">Suggested Destinations</a>
           
           
            </li>
          </ul>
        </div>
      </header>
    </section>
  );
}
