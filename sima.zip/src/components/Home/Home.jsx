import React, {useState} from "react";
import ocean from "../../Video/ocean.mp4";
import "./home.css";
import Data from "../../Data.json";

import Date from "./Date/Date";

// import OriginAndDestination from "./OriginAndDestination/OriginAndDestination";
// import PassengersAndDates from "./PassengersAndDates/PassengersAndDates";

export default function Home() {
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [passengers, setPassengers] = useState("");
  // const [dateFrom, setDateFrom] = useState("");
  // const [dateTo, setDateTo] = useState("");
  const [budget, setBudget] = useState("");

   const handleOriginChange = (event) => {
    setOrigin(event.target.value);
  } ; 
    
  const handleDestinationChange = (event) => {
    setDestination(event.target.value);
  } ; 


  const handlePassengersChange = (event) => {
    setPassengers(event.target.value);
  } ; 

  // const handleDateFromChange = (date) => {
  //   setDateFrom(date.target.value);
  // } ; 

  // const handleDateToChange = (date) => {
  //   setDateTo(date.target.value);
  // } ; 

  const handleBudgetChange = (event) => {
    setBudget(event.target.value);
  } ;

    // handleSearch function to perform the search and display the result
  const handleSearch =()=> {

  }
 

    return (
      <section className="home">
      
        <div className="overlay"></div>
        <video src={ocean} muted autoPlay loop type="ocean/mp4"></video>
  
        <div className="homeContent container">
          <div className="textDiv">
            <span className="smallText">Just Select Your Package</span>
  
            <h1 className="homeTitle">Search Your Holidays</h1>
          </div>
  
          {/* =====origin and destination======================== */}
          {/* <OriginAndDestination /> */}
        
         
          <div className="cardDiv grid">
            <div className="originInput">
              <label htmlFor="city">Search your origin:
               <input
                type={"text"}
                id="city"
                name='Data'
                value= {origin} 
                onChange= {handleOriginChange} 
                placeholder={"Select Your origin here ..."}>
              </input>
              </label>
            </div>
  
            <div className="destinationInput">
              <label htmlFor="city">Search your destination:
              <input
                id="city"
                name="destination"
                value={destination}
                onChange={handleDestinationChange}
                placeholder={"Select Your Destination here ..."}>
                </input>
                </label>
            </div>
          </div>
  
          {/* =====passengers and dates======================== */}
  
          {/* <PassengersAndDates /> */}
  
          <div className="cardDiv">
            <div className="passengersInput">
              <label>Please Enter Number of the Passengers:
              <input
                type= "number" name="passengers" 
                value={passengers} onChange={handlePassengersChange}
                placeholder={"Number of the Passengers ..."}>
              </input>
              </label>
            </div>
             </div>
             
             {/* <label>
      
          <input type="date" name="dateFrom" value={dateFrom}
           onChange={handleDateFromChange} />
        </label>
        
        <label>
          
          <input type="date" name="dateTo" value={dateTo}
           onChange={handleDateToChange} />
        </label> */}
        <Date />
        
        <label>
       
          <input type="number" name="budget" value={budget}
           onChange={handleBudgetChange} />
        </label>
  
          
          <div className="btnSearch">
            <button type="button" onClick={handleSearch} className="btn">Search</button>
          </div>
        </div>
      
      </section>
    );
  }
   
  

    

  
