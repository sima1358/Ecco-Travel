// import React from 'react'
// import './PassengersAndDates.css'

// export default function PassengersAndDates() {
//   return (
//     <div className='cardDiv'>
//         <div className="passengersInput">
//             <label>Please Enter Number of the Passengers:</label>
//             <input
//               type={"number"}
//               placeholder={"Number of the Passengers ..."}
//             ></input>
//           </div>
//           <div className="dateInput">
//             <label htmlFor="date">Enter the Date here:</label>
//             <p>From</p>
//             <input type={"date"}></input>

//             <p>To</p>
//             <input type={"date"}></input>
//           </div>
//     </div>
//   )
// }
