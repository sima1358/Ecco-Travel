import React, { useState } from "react";

export default function Date() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const handleDateFromChange = (event) => {
    setDateFrom(event.target.value);
    
  };

  const handleDateToChange = (event) => {
    const selectedDate = event.target.value;
       if (new Date(selectedDate) >= new Date(dateFrom)) {
       setDateTo(selectedDate);

    // } else {
    //   alert("Date To should be equal or greater than Date From.");
    
      }
    
  };

  return (
    <div>
      <label htmlFor="date-from">Date From: </label>

      <input
        type="date"
        id="date-from"
        value={dateFrom}
        onChange={handleDateFromChange}
      />

      <label htmlFor="date-to">Date To:</label>

      <input
        type="date"
        id="date-to"
        value={dateTo}
        onChange={handleDateToChange}
      />
    </div>
  );
}
